﻿Public Class DroneDogsOrder

    'Method for Calculate Order button click
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        'Declare constants
        Const COST_PER_DOG As Double = 1.99
        Const SALES_TAX_RATE As Double = 0.06
		
		'Declare variables 
		Dim numBeef, numPork, numTurkey, totDogs As Integer
        Dim subtotal, salesTaxAmt, totalCost As Double
		
		'Extract user typed quantities from text boxes and convert to integers
        numBeef = Convert.ToInt32(txtBeefDogs.Text)
        numPork = Convert.ToInt32(txtPorkDogs.Text)
        numTurkey = Convert.ToInt32(txtTurkeyDogs.Text)
		
		'Checking for input validity
        If numBeef < 0 Or numPork < 0 Or numTurkey < 0 Then
            MessageBox.Show("ERROR...Invalid Input. Number can not be negative.")
            Exit Sub
		'Checking for atleast one order
        ElseIf numBeef = 0 And numPork = 0 And numTurkey = 0 Then
            MessageBox.Show("ERROR...You must order at least one item.")
            Exit Sub
        End If
		
		'Calculate total number of hot dogs ordered
        totDogs = numBeef + numPork + numTurkey
		
		'Calculate subtotal, sales tax, and total amounts
        subtotal = totDogs * COST_PER_DOG
        salesTaxAmt = subtotal * SALES_TAX_RATE
        totalCost = subtotal + salesTaxAmt
		
		'Convert numbers back to text and display in text boxes
        txtSubtotal.Text = subtotal.ToString("c2")
        txtSalesTax.Text = salesTaxAmt.ToString("c2")
        txtTotalCost.Text = totalCost.ToString("c2")


    End Sub
	
	'Method for Exit button click
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Close the form
        Me.Close()
    End Sub

	'Method for Get Customer Info button click
    Private Sub btnCustomer_Click(sender As Object, e As EventArgs) Handles btnCustomer.Click
        'Make the customer form visible
        CustomerForm.Show()
    End Sub

	'Method for Clear Form button click
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clear all text fields
        txtBeefDogs.Text = ""
        txtPorkDogs.Text = ""
        txtTurkeyDogs.Text = ""
        txtFirstName.Text = ""
        txtLastName.Text = ""
        txtEmail.Text = ""
        txtSubtotal.Text = ""
        txtSalesTax.Text = ""
        txtTotalCost.Text = ""
		'Clear the permission ckeckbox
        chkPermission.Checked = False
    End Sub

	'Method for Submit Order button click
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        'Check the permission check box, the total cost text box and the email text box
        'Display an error message if any of them are empty
        'Otherwise, display a message box thanking them for ordering
        If chkPermission.Checked = False Then
            MessageBox.Show("ERROR...You must check the location permission check box.")
        ElseIf txtTotalCost.Text = "" Then
            MessageBox.Show("ERROR...You must order at least one item.")
        ElseIf txtEmail.Text = "" Then
            MessageBox.Show("ERROR...Please get customer information for this order.")
        Else
            MessageBox.Show("Thank you for ordering from DroneDogs!")
        End If
    End Sub

  
End Class